package Model.vo;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Date;

public class ParkingUser {
	private String userName; // 이용자 이름
	private int num; // 차번호
	private String arrayLocate; // 주차 A열 B열 C열 , 주차가격 다름 ex.포인트관리 getBonus()
	private int numLocate; //주차 번호
	private LocalDateTime startTime; //등록시간
	private long useTime; //사용시간


	public ParkingUser() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ParkingUser(String userName, int num, String arrayLocate, int numLocate, LocalDateTime startTime) {
		super();
		this.userName = userName;
		this.num = num;
		this.arrayLocate = arrayLocate;
		this.numLocate = numLocate;
		this.startTime = startTime;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public String getArrayLocate() {
		return arrayLocate;
	}

	public void setArrayLocate(String arrayLocate) {
		this.arrayLocate = arrayLocate;
	}

	public int getNumLocate() {
		return numLocate;
	}

	public void setNumLocate(int numLocate) {
		this.numLocate = numLocate;
	}

	public LocalDateTime getStartTime() {
		return startTime;
	}

	public void setStartTime(LocalDateTime startTime) {
		this.startTime = startTime;
	}
	
	/*
	public void setUseTime() {
		LocalDateTime endTime = LocalDateTime.now();
		Duration duration = Duration.between(getStartTime(), endTime);
		this.useTime = duration.toHours();
	}
	*/
	
	public long getUseTime() {
		LocalDateTime endTime = LocalDateTime.now();
		Duration duration = Duration.between(getStartTime(), endTime);
		
		return duration.toHours();
	}

	public long getPay() {
		return getUseTime()*30;
	}
	
	@Override
	public String toString() {
		return userName + "\t" + num + "\t" + arrayLocate + "\t"+ numLocate + "\t" + getUseTime() + "\t" + getPay();
	}
	
	
}
