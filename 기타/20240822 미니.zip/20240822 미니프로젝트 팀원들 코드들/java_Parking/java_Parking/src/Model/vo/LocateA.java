package Model.vo;

import java.time.LocalDateTime;

public class LocateA extends ParkingUser {

	public LocateA() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LocateA(String userName, int num, String arrayLocate, int numLocate, LocalDateTime startTime) {
		super(userName, num, arrayLocate, numLocate, startTime);
		// TODO Auto-generated constructor stub
	}

	public long getPay() {
		return getUseTime()*300;
	}

	

}
