package Model.vo;

import java.time.LocalDateTime;

public class LocateC extends ParkingUser {

	public LocateC() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LocateC(String userName, int num, String arrayLocate, int numLocate, LocalDateTime startTime) {
		super(userName, num, arrayLocate, numLocate, startTime);
		// TODO Auto-generated constructor stub
	}

	@Override
	public long getPay() {
		//System.out.println("장애우/노약자 우대 무료입니다.");
		return 0;
	}

	

}
