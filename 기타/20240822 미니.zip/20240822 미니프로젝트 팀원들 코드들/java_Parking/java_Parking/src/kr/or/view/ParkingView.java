package kr.or.view;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Scanner;

import Model.vo.LocateA;
import Model.vo.LocateB;
import Model.vo.LocateC;
import Model.vo.ParkingUser;

public class ParkingView {
	Scanner sc;
	public ParkingView() {
		sc = new Scanner(System.in);
	}
	
	public int main() {
		System.out.println("========================주차장 관리=======================");
		System.out.println("1.주차 등록");
		System.out.println("2.퇴장/결제");
		System.out.println("3.전체 이용자 출력");
		System.out.println("4.이용자 1명 검색");
		System.out.println("0.종료");
		System.out.print("입력 > ");
		int sellect = sc.nextInt();
		
		return sellect;
	}
	
	//이용자 등록
	public ParkingUser insertUser() {
		System.out.println("====================주차 등록======================");
		System.out.print("등록하실 사용자 이름 : ");
		String name = sc.next();
		System.out.print("등록하실 차 번호 : ");
		int num = sc.nextInt();
		System.out.print("주차 하실 열을 입력해주세요(A:시간당 300원, B:시간당 500원, C:장애우/노약자 우대 공짜) : ");
		String arrayLocate = sc.next();
		System.out.print("주차공간 번호를 입력해 주세요 : ");
		int arrayNum = sc.nextInt();
		LocalDateTime currentDateTime = LocalDateTime.now();
		ParkingUser user;
		
		switch(arrayLocate) {
			case "A":
				user = new LocateA(name,num,arrayLocate,arrayNum,currentDateTime);
				break;
			case "B":
				user = new LocateB(name,num,arrayLocate,arrayNum,currentDateTime);
				break;
			case "C":
				user = new LocateC(name,num,arrayLocate,arrayNum,currentDateTime);
				break;
			default :
				user = null;
				System.out.println("오류 : 다시입력해주세요!!");
				break;
		}
		return user;
	}
	
	//이용자 전체 출력
	public void printAll(ArrayList list) {

		System.out.println("=============전체 책 출력=============");
		System.out.println("이름\t차번호\t열\t위치\t이용시간");
		LocalDateTime currentDateTime = LocalDateTime.now();

		for(int i=0; i<list.size(); i++) {
			
			System.out.println(list.get(i).toString());

		}
	}
	
	//사용자 이름 검색
	public String getName(String msg) {
		System.out.print(msg + "할 사용자 입력 : ");
		String name = sc.next();
		return name;
	}
}
