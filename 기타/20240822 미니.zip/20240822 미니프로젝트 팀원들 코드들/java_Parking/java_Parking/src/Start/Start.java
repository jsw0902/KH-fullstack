package Start;

import java.time.Duration;
import java.time.LocalDateTime;

import Controller.ParkingController;
import Model.vo.ParkingUser;

public class Start {

	public static void main(String[] args) {
		/*
		// TODO Auto-generated method stub
		// 현재 시간 가져오기
        LocalDateTime currentDateTime = LocalDateTime.now();

        // 현재 시간에서 2시간 더한 시간 계산
        LocalDateTime futureDateTime = currentDateTime.plusHours(2);

        // 과거 시간 -1시간
        LocalDateTime pastDateTime = currentDateTime.minusHours(1);
        // 두 시간 사이의 차이 계산
        Duration duration = Duration.between(currentDateTime, futureDateTime);

        // 시간 차이를 정수형 시간으로 변환
        long hours = duration.toHours();
       
        
        System.out.println("현재 시간: " + currentDateTime);
        System.out.println("2시간 후 시간: " + futureDateTime);
        System.out.println("시간 차이: " + hours + " 시간");
        
        
        ParkingUser pu = new ParkingUser();
        pu.setStartTime(pastDateTime);
        System.out.println(pu.getStartTime());
        long hours1 = pu.getUseTime();
        System.out.println("시간 차이 : " + hours1);
        //System.out.println(pu); //2시간 600원 확인
        */
		
		ParkingController parking = new ParkingController();
		parking.prakingMtd();
	}

}
