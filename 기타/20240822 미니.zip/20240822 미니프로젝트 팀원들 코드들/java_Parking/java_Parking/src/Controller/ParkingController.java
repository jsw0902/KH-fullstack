package Controller;

import java.time.LocalDateTime;
import java.util.ArrayList;

import Model.vo.LocateA;
import Model.vo.LocateB;
import Model.vo.ParkingUser;
import kr.or.view.ParkingView;

public class ParkingController {
	ArrayList<ParkingUser> users;
	ParkingView view;
	public ParkingController() {
		view = new ParkingView();
		users = new ArrayList<ParkingUser>();
		
		//시간이 흐른것을 나타내기 위한 사전 등록자 2명
		LocalDateTime currentDateTime = LocalDateTime.now();
		LocalDateTime pastDateTime = currentDateTime.minusHours(1);
		
		LocateA u1 = new LocateA("jjj",222,"A",22,pastDateTime); 
		users.add(u1);
		LocateB u2 = new LocateB("eee",222,"B",22,pastDateTime);
		users.add(u2);
	}
	
	public void prakingMtd() {
		while(true) {
			int sellect = view.main();
			
			switch(sellect) {
			case 1:
				insertMember();
				break;
			case 2:
				deleteMember();
				break;
			case 3:
				printAll();
				break;
			case 4:
				printOne();
				break;
			case 0:
				return;
			default:
				break;
			}
		}
	}
	
	public void insertMember() {
		ParkingUser user = view.insertUser();
		if(user != null) {
			users.add(user);
		}else {
			return;
		}
		System.out.println("등록이 완료 되었습니다.");
	}
	
	public void printAll() {
		view.printAll(users);
	}
	
	public void printOne() {
		String name = view.getName("출력");
		ParkingUser srcUser = searchMember(name);
		if(srcUser != null) {
			System.out.println(srcUser.toString());
		}else {
			System.out.println("등록된 책이 없습니다.");
		}
	}
	
	public ParkingUser searchMember(String name) {
		ParkingUser user;
		for(int i=0; i<users.size(); i++) {
			if(users.get(i).getUserName().equals(name)) {
				user = users.get(i);
				return user;
			}
		}
		return null;
	}
	
	public void deleteMember() {
		String name = view.getName("퇴실");
		ParkingUser srcUser = searchMember(name);
		if(users.contains(srcUser)){
			users.remove(srcUser);
			System.out.println("퇴실 완료");
		}else {
			System.out.println("유저 없슴");
		}
	}
}
